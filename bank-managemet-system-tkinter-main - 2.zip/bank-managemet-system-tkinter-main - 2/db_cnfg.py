from tkinter import *
import datetime
import os
import tkinter.messagebox as MessageBox
from subprocess import call
import mysql.connector as mysql


date = datetime.datetime.now().date()
date= str(date)


class Appli(object):
  def __init__(self, master):
     self.master=master
     def sub():

         passw= StringVar()
         passw=(e_pass.get())
           
         if (passw == "" ):
             MessageBox.showinfo("Illegal insert", "Enter root password")
         else:
                     con=mysql.connect(host= "localhost", user="root" , password=passw)
                     cursor= con.cursor()
                     cursor.execute("SHOW DATABASES")
                     databases = cursor.fetchall()
                     database_exists = False
                     for database in databases:
                        if 'bank_data' in database:
                          database_exists = True
                          break

                     if database_exists:
                       MessageBox.showinfo("Database Status", "Database already exists")
                       quit()
                     else:
                       MessageBox.showinfo("Database Status", "Database to be created")
                       # Execute a SQL file
                       #f = open('my_sql_file_1.sql', 'r')
                       con=mysql.connect(host= "localhost", user="root" , password=passw)
                       cursor= con.cursor()

                       with open('my_sql_file.sql', 'r') as sql_file:
                        result_iterator = cursor.execute(sql_file.read(), multi=True)
                        for res in result_iterator:
                            print("Running query: ", res)  # Will print out a short representation of the query
                            print(f"Affected {res.rowcount} rows" )

                        con.commit()
                        MessageBox.showinfo("Database Status", "Database created")
                        quit()
                       

     #frames

     self.top= Frame(master, height=140 , bg= "white")
     self.top.pack(fill=X)

     self.bottom= Frame(master, height=530, bg="skyblue")
     self.bottom.pack(fill=X)

     #top Frame design
     self.top_image=PhotoImage(file='icon/money.png')
     self.top_image_lable= Label(self.top, image=self.top_image, bg="white")
     self.top_image_lable.place(x=70, y=15)

     self.top_image2=PhotoImage(file='icon/money.png')
     self.top_image2_lable= Label(self.top, image=self.top_image, bg="white")
     self.top_image2_lable.place(x=480, y=15)

     self.heading= Label(self.top, text="Bank Management System", font="arial 15 bold", bg="white")
     self.heading.place(x= 180, y=30)
     self.heading= Label(self.top, text="LOGIN", font="arial 19 bold", bg="white")
     self.heading.place(x= 270, y=90)

     self.date_lbl = Label(self.bottom, text="Date : "+date, bg="skyblue")
     self.date_lbl.place(x=500, y=20)

     #Lable and Enteries


     self.pass_lbl = Label(self.bottom, text="Enter root Password: ", bg="skyblue", font="arial 15 bold")
     self.pass_lbl.place(x=70, y=180)

     e_pass= Entry(self.bottom, width= "40")
     e_pass.place(x=280, y=185)


     # submit
     self.submit= Button(self.bottom, text=" Submit ", font="arial 15 bold", width="30", command=sub)
     self.submit.place(x=105, y=335)



def main():
    root = Tk()
    app=Appli(root)
    root.geometry("600x580+200+20")
    root.resizable(height = 0, width = 0)
    root.mainloop()


if __name__ == "__main__":
    main()
