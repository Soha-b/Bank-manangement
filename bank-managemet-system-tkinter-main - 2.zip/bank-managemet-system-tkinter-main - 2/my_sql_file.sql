## CREATE USER 'bnkcnfg'@'localhost' IDENTIFIED BY '123456';
## GRANT ALL PRIVILEGES ON *.* TO 'bnkcnfg'@'localhost' WITH GRANT OPTION;
CREATE DATABASE bank_data;
USE bank_data;
CREATE TABLE acct (
acc_no int,
fname varchar(255),
lname varchar(255),
d_ob varchar(255),
s_c varchar(255),
amount int,
address varchar(255),
phone_no int,
m_f_t varchar(255),
email varchar(255),
status varchar(255),
crt_dte varchar(255),
pin varchar(255),
Constraint Pk_acct PRIMARY KEY (acc_no)
);
CREATE TABLE dlt (
acc_no int,
fname varchar(255),
lname varchar(255),
d_ob varchar(255),
s_c varchar(255),
amount int,
address varchar(255),
phone_no int,
m_f_t varchar(255),
email varchar(255),
status varchar(255),
crt_dte varchar(255)
);
CREATE TABLE mgmt (
managerid varchar(255),
pass varchar(255)
);
CREATE TABLE ttxn (
acc_no int,
amt int,
a_s varchar(255),
txn_dte varchar(255)
);
CREATE TABLE users(
idusers varchar(255),
passusr varchar(255),
f_log varchar(255)
);
CREATE TABLE Persons (
    PersonID varchar(255),
    LastName varchar(255),
    FirstName varchar(255),
    Address varchar(255),
    City varchar(255)
);
Commit;