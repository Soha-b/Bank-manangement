from tkinter import *
import os
import tkinter.messagebox as MessageBox
from subprocess import call
import mysql.connector as mysql
import datetime

def create_acc():
    #call(["python", "create_acc.py"])
    date = datetime.datetime.now().date()
    date= str(date)

    class Appli(object):
      def __init__(self, master1):
         self.master1=master1
         def sub():
             acc_no= DoubleVar()
             amount= DoubleVar()
             phone_no= DoubleVar()
             acc_no = (e_acc_no.get())
             fname = (e_fname.get())
             lname = (e_lname.get())
             d_ob= (e_d_ob.get())
             s_c = (t.get())
             amount = (e_amount.get())
             address = (e_address.get())
             phone_no = (e_phone_no.get())
             m_f_t = (i.get())

             if (acc_no == "" or fname == "" or s_c == "" or amount =="" or address =="" or phone_no == "" or m_f_t ==""):
                 MessageBox.showinfo("Illegal insert", "All Fields are Required")    
             else:
                 con=mysql.connect(host= "localhost", user="root" , password="2023", database="bank_data")
                 cursor= con.cursor()
                 cursor.execute("insert into acct (acc_no, fname, lname, d_ob, s_c, amount, address, phone_no, m_f_t) values('" + acc_no + "','"+ fname +"','"+ lname +"','"+ d_ob +"', '"+ s_c +"','"+ amount +"' , '"+ address +"','" + phone_no + "', '"+ m_f_t +"')")
                 #cursor.execute("insert into users values('" + acc_no + "','"+ phone_no +"')")
                 cursor.execute("commit")
                 MessageBox.showinfo("Insert Status", "Inserted Successfully")
                 e_fname.delete(0,'end')
                 e_lname.delete(0,'end')
                 e_amount.delete(0,'end')
                 e_address.delete(0,'end')
                 e_phone_no.delete(0,'end')
                 e_d_ob.delete(0,'end')
                 con.close()


         #frames

         self.top= Frame(master1, height=100 , bg= "white")
         self.top.pack(fill=X)

         self.bottom= Frame(master1, height=800, bg="#fcad03")
         self.bottom.pack(fill=X)

         #top Frame design
         self.top_image=PhotoImage(file='icon/money1.png')
         self.top_image_lable= Label(self.top, image=self.top_image, bg="white")
         self.top_image_lable.place(x=100, y=15)

         self.top_image2=PhotoImage(file='icon/money.png')
         self.top_image2_lable= Label(self.top, image=self.top_image, bg="white")
         self.top_image2_lable.place(x=750, y=15)

         self.heading= Label(self.top, text="Create Account", font="arial 18 bold", bg="white")
         self.heading.place(x= 370, y=30)

         #bottom Frame Design

         #buttons and lables
         acc_no= DoubleVar()
         acc_no = Label(self.bottom, text="Account number ", font="arial 14 bold", bg="#fcad03")
         acc_no.place(x=40, y=60)

         fname = Label(self.bottom, text="First Name ", font="arial 14 bold", bg="#fcad03")
         fname.place(x=40, y=100)

         lname = Label(self.bottom, text="Last Name ", font="arial 14 bold", bg="#fcad03")
         lname.place(x=40, y=140)

         s_c = Label(self.bottom, text="Account Type ", font="arial 14 bold", bg="#fcad03")
         s_c.place(x=40, y=180)

         amount= DoubleVar()
         amount = Label(self.bottom, text="Initial Amount ", font="arial 14 bold", bg="#fcad03")
         amount.place(x=40, y=220)

         address = Label(self.bottom, text="Address ", font="arial 14 bold", bg="#fcad03")
         address.place(x=40, y=260)
         
         phone_no= DoubleVar()
         phone_no = Label(self.bottom, text="Phone Number ", font="arial 14 bold", bg="#fcad03")
         phone_no.place(x=40, y=300)

         m_f_t = Label(self.bottom, text="Sex ", font="arial 14 bold", bg="#fcad03")
         m_f_t.place(x=40, y=340)

         d_ob = Label(self.bottom, text="Date of Birth ", font="arial 14 bold", bg="#fcad03")
         d_ob.place(x=40, y=380)

         #Enteries
         
         e_acc_no= Entry(self.bottom, width= "60", textvariable=acc_no)
         e_acc_no.place(x=320, y=60)

         e_fname= Entry(self.bottom, width= "60")
         e_fname.place(x=320, y=100)

         e_lname= Entry(self.bottom, width= "60")
         e_lname.place(x=320, y=140)

         t= StringVar()
         Radiobutton(self.bottom, text="Savings Account",  value="S", bg="#fcad03", variable=t).place(x=320, y=180)
         Radiobutton(self.bottom, text="Current Account",  value="C", bg="#fcad03", variable=t).place(x=450, y=180)

         e_amount= Entry(self.bottom, width= "60")
         e_amount.place(x=320, y=220)

         e_address= Entry(self.bottom, width= "60")
         e_address.place(x=320, y=260)
         
         e_phone_no= Entry(self.bottom, width= "60")
         e_phone_no.place(x=320, y=300)

         i= StringVar()
         Radiobutton(self.bottom, text="Male",  value="M", bg="#fcad03", variable=i).place(x=320, y=340)
         Radiobutton(self.bottom, text="Female",  value="F", bg="#fcad03", variable=i).place(x=430, y=340)
         Radiobutton(self.bottom, text="Transgender",  value="T", bg="#fcad03", variable=i).place(x=540, y=340)

         e_d_ob= Entry(self.bottom, width= "60")
         e_d_ob.place(x=320, y=380)

         #submit
         self.submit= Button(self.bottom, text=" Submit ", font="arial 15 bold", width="30", command=sub)
         self.submit.place(x=320 , y=440)
         

    def main1():
        root1 = Tk()
        app=Appli(root1)
        root1.geometry("900x600+200+0")
        root1.resizable(height = 0, width = 0)
        root1.mainloop()



    if __name__ == "__main__":
        main1()



#########################################################################


    
def delt_acc():
    #call(["python", "delt.py"])

    class Appli(object):
      def __init__(self, master):
         self.master=master
         def delti():
             acc_no= DoubleVar()
             acc_no = (e_acc_no.get())

             if (acc_no == "" ):
                 MessageBox.showinfo("ID is required for delete", "All Fields are Required")    
             else:
                 con=mysql.connect(host= "localhost", user="root" , password="rockstarxxx", database="bank_data")
                 cursor= con.cursor()
                 cursor.execute("delete from acct where acc_no='" + acc_no + "'")
                 cursor.execute("commit")
                 lb.delete(1,'end')
                 lb.delete(2,'end')
                 lb.delete(3,'end')
                 lb.delete(4,'end')
                 lb.delete(5,'end')
                 lb.delete(6,'end')
                 lb.delete(7,'end')
                 lb.delete(8,'end')
                 lb.delete(9,'end')
                 lb.delete(10,'end')
                 lb.delete(11,'end')
                 lb.delete(12,'end')
                 lb.delete(13,'end')
                 lb.delete(14,'end')
                 e_acc_no.delete(0,'end')
                 MessageBox.showinfo("Delete Status", "Deleted Successfully")
                 con.close()

         def sub():
             acc_no= DoubleVar()
             acc_no = (e_acc_no.get())

             if (acc_no == "" ):
                 MessageBox.showinfo("Illegal insert", "All Fields are Required")    
             else:
                 con=mysql.connect(host= "localhost", user="root" , password="rockstarxxx", database="bank_data")
                 cursor= con.cursor()
                 cursor.execute("select * from acct where acc_no='" + acc_no + "'")
                 myresult = cursor.fetchall()
                 print(myresult)
                 for x in myresult:
                     lb.insert(1,"Account No. :" )
                     lb.insert(2,x[0])
                     lb.insert(3,"Name :")
                     lb.insert(4,x[1] + " " + x[2])
                     lb.insert(5,"Account Type :")
                     lb.insert(6,x[3])
                     lb.insert(7,"Amount :")
                     lb.insert(8,x[4])
                     lb.insert(9,"Address :")
                     lb.insert(10,x[5])
                     lb.insert(11,"Phone No. :")
                     lb.insert(12,x[6])
                     lb.insert(13,"Sex")
                     lb.insert(14,x[7])
                     
                 cursor.execute("commit")
                 con.close()
                 

                 


         #frames

         self.top= Frame(master, height=100 , bg= "white")
         self.top.pack(fill=X)

         self.bottom= Frame(master, height=800, bg="#fcad03")
         self.bottom.pack(fill=X)

         #top Frame design
         self.top_image=PhotoImage(file='icon/money.png')
         self.top_image_lable= Label(self.top, image=self.top_image, bg="white")
         self.top_image_lable.place(x=50, y=15)

         self.top_image2=PhotoImage(file='icon/money.png')
         self.top_image2_lable= Label(self.top, image=self.top_image, bg="white")
         self.top_image2_lable.place(x=580, y=15)

         self.heading= Label(self.top, text="Delete Account", font="arial 18 bold", bg="white")
         self.heading.place(x= 265, y=30)

         #bottom Frame Design

         #buttons and lables
         acc_no= DoubleVar()
         acc_no = Label(self.bottom, text="Account number ", font="arial 14 bold", bg="#fcad03")
         acc_no.place(x=40, y=55)

         detail = Label(self.bottom, text="Details -> ", font="arial 14 bold", bg="#fcad03")
         detail.place(x=40, y=110)

         #Enteries
         
         e_acc_no= Entry(self.bottom, width= "60", textvariable=acc_no)
         e_acc_no.place(x=320, y=55)


         #list
         lb= Listbox(self.bottom,height="50", width="60" )
         lb.place(x=320 , y= 110)



         #submit
         self.submit= Button(self.bottom, text=" Submit ", font="arial 15 bold", width="20", command=sub)
         self.submit.place(x=45 , y=200)

         self.delt= Button(self.bottom, text=" Delete ", font="arial 15 bold", width="20", command=delti)
         self.delt.place(x=45 , y=300)
         

    def main1():
        root = Tk()
        app=Appli(root)
        root.geometry("700x500+200+20")
        root.resizable(height = 0, width = 0)
        root.main1loop()



    if __name__ == "__main__":
        main1()

        



##################################################################


    
def balq():
    call(["python", "bal_eq.py"])
def chk():
    call(["python", "chk_acc.py"])
def bw():
    call(["python", "bal_wd.py"])
def bd():
    call(["python", "bal_dep.py"])
def upd():
    call(["python", "upd_acc.py"])        

date = datetime.datetime.now().date()
date= str(date)



class Appli(object):
  def __init__(self, master):
     self.master=master

     #frames

     self.top= Frame(master, height=100 , bg= "white")
     self.top.pack(fill=X)

     self.bottom= Frame(master, height=530, bg="#fcad03")
     self.bottom.pack(fill=X)

     #top Frame design
     self.top_image=PhotoImage(file='icon/money.png')
     self.top_image_lable= Label(self.top, image=self.top_image, bg="white")
     self.top_image_lable.place(x=70, y=15)

     self.top_image2=PhotoImage(file='icon/money.png')
     self.top_image2_lable= Label(self.top, image=self.top_image, bg="white")
     self.top_image2_lable.place(x=480, y=15)

     self.heading= Label(self.top, text="Bank Management System", font="arial 15 bold", bg="white")
     self.heading.place(x= 180, y=30)

     self.date_lbl = Label(self.bottom, text="Date : "+date, bg="#fcad03")
     self.date_lbl.place(x=500, y=20)

     #buttons

     #Createacc
     self.ca= Button(self.bottom, text=" Create Account ", font="arial 13 bold", command=create_acc, width=20)
     self.ca.place(x=40, y=50)
     self.ca_lbl = Label(self.bottom, text="> Create new user account", bg="#fcad03", font="arial 13 bold")
     self.ca_lbl.place(x=280, y=52)

     #Balance enquiry
     self.Be= Button(self.bottom, text=" Balance Enquiry ", font="arial 13 bold", command=balq, width=20)
     self.Be.place(x=40, y=120)
     self.be_lbl = Label(self.bottom, text="> Check Account Balance", bg="#fcad03", font="arial 13 bold")
     self.be_lbl.place(x=280, y=122)

     #Check Accounnt
     self.Caa= Button(self.bottom, text=" Check Account Details ", font="arial 13 bold", command=chk, width=20)
     self.Caa.place(x=40, y=190)
     self.caa_lbl = Label(self.bottom, text="> Check account details", bg="#fcad03", font="arial 13 bold")
     self.caa_lbl.place(x=280, y=192)

     #Balance Withdraw
     self.Bw= Button(self.bottom, text=" Balance Withdraw ", font="arial 13 bold", command=bw, width=20)
     self.Bw.place(x=40, y=260)
     self.bw_lbl = Label(self.bottom, text="> Withdraw Amount from user Account", bg="#fcad03", font="arial 13 bold")
     self.bw_lbl.place(x=280, y=262)

     #Balance Deposit
     self.Bd= Button(self.bottom, text=" Balance Deposit ", font="arial 13 bold", command=bd, width=20)
     self.Bd.place(x=40, y=340)
     self.bd_lbl = Label(self.bottom, text="> Deposit Amount from user Account", bg="#fcad03", font="arial 13 bold")
     self.bd_lbl.place(x=280, y=342)

     #Delete Account
     self.Au= Button(self.bottom, text=" Delete Account ", font="arial 13 bold", command=delt_acc, width=20)
     self.Au.place(x=40, y=410)
     self.bd_lbl = Label(self.bottom, text="> Delete user Account", bg="#fcad03", font="arial 13 bold")
     self.bd_lbl.place(x=280, y=412)

     self.Au= Button(self.bottom, text=" Update Account ", font="arial 13 bold", command=upd, width=20)
     self.Au.place(x=40, y=480)
     self.bd_lbl = Label(self.bottom, text="> Update user Account", bg="#fcad03", font="arial 13 bold")
     self.bd_lbl.place(x=280, y=482)



def main():
    root = Tk()
    app=Appli(root)
    root.geometry("600x630+100+20")
    root.resizable(height = 0, width = 0)
    root.mainloop()


if __name__ == "__main__":
    main()
