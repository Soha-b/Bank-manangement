#import pymysql
import mysql.connector

def get_connection():
    con = mysql.connector.connect(host="localhost", user="root", password="123456", db="bank_data")
    cursor = con.cursor()
    return cursor, con
